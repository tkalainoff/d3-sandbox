<script>
  // Logic
  let instructor = "Connor";
</script>

<!-- Content -->
<h1>{instructor} is excited to have you in this course!</h1>

<style>
  /* Design */
  h1 {
    font-size: 18px;
  }
</style>
