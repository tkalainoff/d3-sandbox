async function drawBars() {
  // your code goes here

}
drawBars()