async function drawLineChart() {
  // write your code here

}

drawLineChart()