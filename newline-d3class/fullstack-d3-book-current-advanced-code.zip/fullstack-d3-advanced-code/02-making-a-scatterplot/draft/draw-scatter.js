async function drawScatter() {
  // your code goes here
  
}
drawScatter()