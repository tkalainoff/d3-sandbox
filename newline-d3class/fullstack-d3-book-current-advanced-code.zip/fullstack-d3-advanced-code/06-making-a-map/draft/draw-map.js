async function drawMap() {
  // your code goes here

}
drawMap()