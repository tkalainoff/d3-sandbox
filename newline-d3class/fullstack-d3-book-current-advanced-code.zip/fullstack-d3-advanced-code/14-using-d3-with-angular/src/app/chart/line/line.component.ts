import { Component, Input, OnChanges, SimpleChanges } from '@angular/core'
import * as d3 from "d3"

@Component({
  selector: '[appLine]',
  template: ``,
  styleUrls: ['./line.component.css']
})
export class LineComponent {
}
