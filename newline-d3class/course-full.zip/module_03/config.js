module.exports = ({ dedent }) => ({
  title: "Animations and Transitions",
  slug: "animations-and-transitions",
  role: "MODULE"
});
