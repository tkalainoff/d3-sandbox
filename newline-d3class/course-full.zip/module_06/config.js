module.exports = ({ dedent }) => ({
  title: "Advanced example",
  slug: "advanced-example",
  role: "MODULE"
});
