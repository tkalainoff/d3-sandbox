---
title: "Week 6: Exercise"
description: Let's consolidate what we just learned with an exercise to play with this week.
---

# This week's exercise

Awesome work getting through all of those design tricks! During this week, redesign one of the custom charts you created in our previous exercises, using the concepts we learned this week!

Choose whichever chart you are most excited about redesigning. Try to go as far outside the box as possible - no worries if your first few attempts don't work out, this is the time to learn your taste and what works for you!

**Now, go over the same steps we went through this week to redesign one of your custom charts, as much as possible.**

If you get stuck, watch this week's videos again or post a question inline or on the Discord channel. Good luck! We're rooting for you!

And once you're finished, show off your wonderful custom visualization on Twitter or on the Discord! We'd love to see it!