module.exports = ({ dedent }) => ({
  title: "Data Visualization Basics",
  slug: "data-visualization-basics",
  role: "MODULE"
});
