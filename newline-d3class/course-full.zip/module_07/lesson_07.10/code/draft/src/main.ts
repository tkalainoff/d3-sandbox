// polyfills
import 'core-js/es/reflect';
import "core-js/proposals/reflect-metadata";
import "zone.js/dist/zone";

import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
