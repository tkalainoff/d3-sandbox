module.exports = ({ dedent }) => ({
  title: "D3 + Javascript Frameworks",
  slug: "d3-javascript-frameworks",
  role: "MODULE"
});
