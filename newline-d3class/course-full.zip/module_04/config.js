module.exports = ({ dedent }) => ({
  title: "Interactions",
  slug: "interactions",
  role: "MODULE"
});
