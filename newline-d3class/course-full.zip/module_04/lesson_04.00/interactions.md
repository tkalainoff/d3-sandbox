---
title: "Interactions"
description: "Let's start talking about adding interactions to our charts!"
useMdx: true
privateVideoUrl: https://fullstack.wistia.com/medias/6qcyu7shn2
isPublicLesson: true
---

# Interactions

The biggest advantage of creating charts with JavaScript is the ability to respond to user input. In this module, we'll learn what ways users can interact with our graphs and how to implement them.
