module.exports = ({ dedent }) => ({
  title: "Interviews",
  slug: "interviews",
  role: "MODULE"
});
