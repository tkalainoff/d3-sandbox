---
title: "Interviews"
description: "Coming soon! Interviews with amazing experts in the data visualization field. You'll learn about how different people get into data visualization, what most excites them, and their tips & tricks."
# privateVideoUrl:
---

# Interviews

Coming soon! Interviews with amazing experts in the data visualization field. You'll learn about how different people get into data visualization, what most excites them, and their tips & tricks.