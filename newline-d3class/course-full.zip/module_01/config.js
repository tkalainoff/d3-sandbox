module.exports = ({ dedent }) => ({
  title: "Making a Scatterplot",
  slug: "making-a-scatterplot",
  role: "MODULE"
});
