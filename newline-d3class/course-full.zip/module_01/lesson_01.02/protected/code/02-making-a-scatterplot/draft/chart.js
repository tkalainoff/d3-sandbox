import * as d3 from "d3";

async function drawScatter() {
  // your code goes here

}
drawScatter()