module.exports = ({ dedent }) => ({
  title: "Making Your First Chart",
  slug: "making-your-first-chart",
  role: "MODULE"
});
