import * as d3 from "d3";

async function drawBars() {
  // your code goes here

}
drawBars()