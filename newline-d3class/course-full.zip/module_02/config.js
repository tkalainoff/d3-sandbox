module.exports = ({ dedent }) => ({
  title: "Making a Bar Chart",
  slug: "making-a-bar-chart",
  role: "MODULE"
});
